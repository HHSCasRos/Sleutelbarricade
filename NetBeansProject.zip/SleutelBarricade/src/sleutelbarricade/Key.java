package sleutelbarricade;

public class Key {
    private final int idCode;
    
    public Key(int idCode){
        this.idCode = idCode;
    }

    public int getIdCode() {
        return idCode;
    }
}